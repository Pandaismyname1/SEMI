package dev.emi.emi.api.recipe;

import java.util.List;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.Nullable;

import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import dev.emi.emi.runtime.EmiDrawContext;

public class EmiInfoRecipe implements EmiRecipe {
	private static final int STACK_WIDTH = 6, MAX_STACKS = STACK_WIDTH * 3;
	private static final int PADDING = 4;
	private static final Minecraft CLIENT = Minecraft.getInstance();
	private final List<EmiIngredient> stacks;
	private final List<Component> rawText;
	private final Identifier id;
	private volatile List<FormattedCharSequence> text;

	public EmiInfoRecipe(List<EmiIngredient> stacks, List<Component> text, @Nullable Identifier id) {
		this.stacks = stacks;
		this.rawText = List.copyOf(text);
		this.id = id;
	}

	/**
	 * Word wrapping resolves every glyph through the font, which stitches it into the font atlas and
	 * touches the GPU, so it must not happen while EMI is constructing recipes on its reload thread.
	 * Info recipes are created there (from data packs and from JEI plugins), so the wrapping is
	 * deferred until the recipe is first laid out or drawn, both of which happen on the render
	 * thread. The assertion below makes a plugin that calls in from anywhere else fail loudly
	 * instead of corrupting the font atlas, and the field is volatile so the render thread never
	 * publishes a half-built list.
	 */
	private List<FormattedCharSequence> getText() {
		List<FormattedCharSequence> text = this.text;
		if (text == null) {
			RenderSystem.assertOnRenderThread();
			text = rawText.stream().flatMap(t -> CLIENT.font.split(t, getDisplayWidth() - 4).stream()).toList();
			this.text = text;
		}
		return text;
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return VanillaEmiRecipeCategories.INFO;
	}

	@Override
	public @Nullable Identifier getId() {
		return id;
	}

	@Override
	public List<EmiIngredient> getInputs() {
		return stacks;
	}

	@Override
	public List<EmiStack> getOutputs() {
		return stacks.stream().flatMap(ing -> ing.getEmiStacks().stream()).toList();
	}

	@Override
	public boolean supportsRecipeTree() {
		return false;
	}

	@Override
	public int getDisplayWidth() {
		return 144;
	}

	@Override
	public int getDisplayHeight() {
		int stackHeight = ((Math.min(stacks.size(), MAX_STACKS) - 1) / STACK_WIDTH + 1) * 18;
		return stackHeight + CLIENT.font.lineHeight * getText().size() + PADDING;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		int stackCount = Math.min(stacks.size(), MAX_STACKS);
		int stackHeight = ((stackCount - 1) / STACK_WIDTH + 1);
		int xOff = 54 - (stackCount % STACK_WIDTH * 9);
		for (int i = 0; i < stackCount; i++) {
			int y = i / STACK_WIDTH * 18;
			int x = (i % STACK_WIDTH) * 18;
			if (y / 18 + 1 == stackHeight && stackCount % STACK_WIDTH != 0) {
				x += xOff;
			}
			if (i + 1 == stackCount && stacks.size() > stackCount) {
				widgets.addSlot(EmiIngredient.of(stacks.subList(i, stacks.size())), x + 18, y);
			} else {
				widgets.addSlot(stacks.get(i), x + 18, y);
			}
		}
		int y = stackHeight * 18 + PADDING;
		int lineCount = (widgets.getHeight() - y) / CLIENT.font.lineHeight;
		List<FormattedCharSequence> lines = getText();
		PageManager manager = new PageManager(lines, lineCount);
		if (lineCount < lines.size()) {
			widgets.addButton(2, 2, 12, 12, 0, 0, () -> true, (mouseX, mouseY, button) -> {
				manager.scroll(-1);
			});
			widgets.addButton(widgets.getWidth() - 14, 2, 12, 12, 12, 0, () -> true, (mouseX, mouseY, button) -> {
				manager.scroll(1);
			});
		}
		widgets.addDrawable(0, y, 0, 0, (raw, mouseX, mouseY, delta) -> {
			EmiDrawContext context = EmiDrawContext.wrap(raw);
			int lo = manager.start();
			for (int i = 0; i < lineCount; i++) {
				int l = lo + i;
				if (l >= manager.lines.size()) {
					return;
				}
				FormattedCharSequence text = manager.lines.get(l);
				context.drawText(text, 0, y - y + i * CLIENT.font.lineHeight, 0);
			}
		});
	}

	private static class PageManager {
		public final List<FormattedCharSequence> lines;
		public final int pageSize;
		public int currentPage;

		public PageManager(List<FormattedCharSequence> lines, int pageSize) {
			this.lines = lines;
			this.pageSize = pageSize;
		}

		public void scroll(int delta) {
			currentPage += delta;
			int totalPages = (lines.size() - 1) / pageSize + 1;
			if (currentPage < 0) {
				currentPage = totalPages - 1;
			}
			if (currentPage >= totalPages) {
				currentPage = 0;
			}
		}

		public int start() {
			return currentPage * pageSize;
		}
	}
}
